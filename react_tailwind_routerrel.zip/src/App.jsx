

function App() {
  

  return (
   
      <div>
        <h1 className="text-3xl font-bold text-center text-sky-500">Tailwind CSS</h1>
        
      </div>
  )
}

export default App
