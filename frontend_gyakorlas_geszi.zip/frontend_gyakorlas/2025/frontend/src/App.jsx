


function App() {
  
  return (
    
      <div>                
	Frontend vizsgafeladat 2025	

      </div>
       
    
  )
}

export default App
