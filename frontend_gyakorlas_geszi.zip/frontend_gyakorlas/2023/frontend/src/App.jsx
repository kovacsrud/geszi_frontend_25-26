

function App() {
 

  return (
    <div>
      <h1 className="text-5xl font-bold bg-red-200 text-red-900 text-center p-4">Trolibusz hálózat</h1>
    </div>
  )
}

export default App
